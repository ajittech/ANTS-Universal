
$(document).ready(function(){
	var sound = $('.sound')[0];
        sound.volume = 0.2;
		$('.main-button').mouseover(function(){
		sound.play();
	});
})
window.onscroll = function() { scrollFunction() };
function scrollFunction() {
    var headerheight = $('header').height();
    if (document.body.scrollTop > headerheight|| document.documentElement.scrollTop > headerheight){
        document.querySelector('header').classList.add('header_fixed');
        document.getElementById("tp-button").style.display = "block";
    }
    else if (document.body.scrollTop <= headerheight|| document.documentElement.scrollTop <= headerheight){
        document.querySelector('header').classList.remove('header_fixed');
        document.getElementById("tp-button").style.display = "none";
    }
}
$('.button1').click(function(){
	$('html,body').animate({
    scrollTop: $(".customer-section").offset().top},
    1000);
});
$('.button2').click(function(){
	$('html,body').animate({
    scrollTop: $(".e-learning").offset().top},
    1000);
});
$('.button3').click(function(){
	$('html,body').animate({
    scrollTop: $(".product").offset().top},
    1000);
});

$(document).ready(function(){
	$('.spinner-content').addClass('spinner');
	setTimeout(function(){
		$('.shadow, .caption').fadeIn(2000);
	},8000);
	$('.button1').mouseover(function(){
		$('.button1').attr('src','assets/images/gamification/button1pressed.png');
		$('.shadow1').hide();
	});
	$('.button1').mouseleave(function(){
		$('.button1').attr('src','assets/images/gamification/button1.png');
		$('.shadow1').show();
	});

	$('.button2').mouseover(function(){
		$('.button2').attr('src','assets/images/gamification/button2pressed.png');
		$('.shadow2').hide();
	});
	$('.button2').mouseleave(function(){
		$('.button2').attr('src','assets/images/gamification/button2.png');
		$('.shadow2').show();
	});

	$('.button3').mouseover(function(){
		$('.button3').attr('src','assets/images/gamification/button3pressed.png');
		$('.shadow3').hide();
	});
	$('.button3').mouseleave(function(){
		$('.button3').attr('src','assets/images/gamification/button3.png');
		$('.shadow3').show();
	});
})
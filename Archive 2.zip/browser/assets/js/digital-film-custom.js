window.onscroll = function() { scrollFunction(); animateonscroll(); };

function scrollFunction() {
    var headerheight = $('header').height();
    if (document.body.scrollTop > headerheight|| document.documentElement.scrollTop > headerheight){
        document.querySelector('header').classList.add('header_fixed');
        document.getElementById("tp-button").style.display = "block";
    }
    else if (document.body.scrollTop <= headerheight|| document.documentElement.scrollTop <= headerheight){
        document.querySelector('header').classList.remove('header_fixed');
        document.getElementById("tp-button").style.display = "none";
    }
}
function animateonscroll(){
    
    var anim1 = document.getElementById('anim1');
    var anim2 = document.getElementById('anim2');
    var anim3 = document.getElementById('anim3');
    var anim4 = document.getElementById('anim4');
    var anim5 = document.getElementById('anim5');
    var animCircleMain = document.getElementsByClassName('main-circle');
    var anim1Circle = document.getElementsByClassName('main-circle1')[0];
    var anim2Circle = document.getElementsByClassName('main-circle2')[0];
    var anim3Circle = document.getElementsByClassName('main-circle3')[0];
    var anim4Circle = document.getElementsByClassName('main-circle4')[0];
    var anim5Circle = document.getElementsByClassName('main-circle5')[0];
    var waveOffset = $('.startwave').offset().top;
    var winHeight = $(window).height();
    var finalOutput = waveOffset - (2*winHeight/3);
    var anim1trigger = finalOutput + 100;
    var anim2trigger = finalOutput + 200;
    var anim3trigger = finalOutput + 300;
    var anim4trigger = finalOutput + 400;
    var anim5trigger = finalOutput + 500;
    function inactive (){
        for(let i=0; i<animCircleMain.length; i++){
           animCircleMain[i].classList.remove('active');
        }
    }
    if (document.documentElement.scrollTop > anim1trigger && document.documentElement.scrollTop < anim1trigger+50){
        anim1.beginElement();
        inactive();
        anim1Circle.classList.add('active');
    }
    else if (document.documentElement.scrollTop > anim2trigger && document.documentElement.scrollTop < anim2trigger+150){
        anim2.beginElement();
        inactive();
        anim2Circle.classList.add('active');
    }
    else if (document.documentElement.scrollTop > anim3trigger && document.documentElement.scrollTop < anim3trigger+250){
        anim3.beginElement();
        inactive();
        anim3Circle.classList.add('active');
    }
    else if (document.documentElement.scrollTop > anim4trigger && document.documentElement.scrollTop < anim4trigger+350){
        anim4.beginElement();
        inactive();
        anim4Circle.classList.add('active');
    }
    else if (document.documentElement.scrollTop > anim5trigger && document.documentElement.scrollTop < anim5trigger+450){
        anim5.beginElement();
        inactive();
        anim5Circle.classList.add('active');
    }
    else {
        inactive();
    }
    
    $('.zigzag-video-single .vidchat').each(function(){
        var currentOffset = $(this).offset().top;
        var wintHeight = $(window).height();
        var startAnimatePos = currentOffset - (2*wintHeight/3);
        if (document.body.scrollTop > startAnimatePos || document.documentElement.scrollTop > startAnimatePos){
            $(this).addClass('fadeit');
        }
        else {
            $(this).removeClass('fadeit');
        }
    })
}

window.addEventListener('load', function(){
    setTimeout(function(){
        document.getElementsByClassName('banner-triangle')[0].classList.add('active');
    }, 1000);  
})


function pauseAll(){
    var allvid = document.getElementsByClassName('common-video');
    for(var i=0; i<allvid.length; i++) {
        var ele = allvid[i];
        ele.pause();
        ele.parentElement.parentElement.getElementsByClassName('fa-play')[0].classList.remove('fa-pause');
    }
}

/* Banner Video JS */
var bannerVideo = document.getElementById('banner-video');
function triggerVideo(ele){
    var icon = ele.getElementsByTagName('i')[0];
    if(!icon.classList.contains('fa-pause') && bannerVideo.paused){
        icon.classList.add('fa-pause');
        bannerVideo.play()
    }
    else{
        icon.classList.remove('fa-pause');
        bannerVideo.pause()
    }
}
var commonPlayBtn = document.getElementsByClassName('common-play-btn');
for(let i=0; i<commonPlayBtn.length; i++) {
    commonPlayBtn[i].addEventListener('click', function(){ 
        var currentVideo = this.parentElement.getElementsByClassName('common-video')[0];
        var icon = this.getElementsByTagName('i')[0];
        if(!icon.classList.contains('fa-pause') && currentVideo.paused){
            pauseAll();
            currentVideo.play();
            icon.classList.add('fa-pause');
        }
        else {
            currentVideo.pause();
            icon.classList.remove('fa-pause');
        }
    })
}


// $('.speak-cp-slider').owlCarousel({
//     items:1,
//     loop:true,
//     margin:0,
//     autoplay:true,
//     nav: true,
//     navText: ['<i class="fa fa-chevron-left"></i>','<i class="fa fa-chevron-right"></i>'],
//     dots: false,
//     autoplayTimeout:5000,
//     autoplayHoverPause:true,
//     onTranslated: function(){
//         var currentCount = $('.speak-cp-slider .owl-item.active .speak-big-count').text();
//         var currentImg = $('.speak-cp-slider .owl-item.active .item').data('image');
//         $('.speak-counter .current-count').text(currentCount);
//         $('.picture-speak .main-pic').attr('src','digital-film-files/images/'+currentImg);
//     }
// });


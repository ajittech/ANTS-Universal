
$(document).ready(function(){
 first_screen_width();
 $(window).on('resize', function(){
 	first_screen_width();
 });
 function first_screen_width(){
 	var min_height = $(window).height()
 	$('.main-banner').css('min-height',min_height);
 }
})

$(document).ready(function(){
	var sound = $('.sound')[0];
        sound.volume = 0.2;
		$('.photo3').mouseover(function(){
		sound.play();
	});
})

window.onscroll = function() { scrollFunction() };
function scrollFunction() {
    var headerheight = $('header').height();
    if (document.body.scrollTop > headerheight|| document.documentElement.scrollTop > headerheight){
        document.querySelector('header').classList.add('header_fixed');
        document.getElementById("tp-button").style.display = "block";
    }
    else if (document.body.scrollTop <= headerheight|| document.documentElement.scrollTop <= headerheight){
        document.querySelector('header').classList.remove('header_fixed');
        document.getElementById("tp-button").style.display = "none";
    }
    
}

$('.top').click(function(){
	$('html,body').animate({
    scrollTop: $("body").offset().top},
    1000);
});

$(document).ready(function(){
	$('.photography-button .photo3').mouseover(function(){
		$('.photography-button .photo3').attr('src','assets/images/creative-design/photography3pressed.svg');
		$('.photography-button .shadow').hide();
		$('.photography-button .photo1').addClass('rotate180');
		$('.photography-button .photo2').addClass('rotatetranslate180');
	});
	$('.photography-button .photo3').mouseleave(function(){
		$('.photography-button .photo3').attr('src','assets/images/creative-design/photography3.svg');
		$('.photography-button .shadow').show();
		$('.photography-button .photo1').removeClass('rotate180');
		$('.photography-button .photo2').removeClass('rotatetranslate180');
	});

	$('.digital-button .photo3').mouseover(function(){
		$('.digital-button .photo3').attr('src','assets/images/creative-design/digital3pressed.svg');
		$('.digital-button .shadow').hide();
		$('.digital-button .photo1').addClass('rotate180');
		$('.digital-button .photo2').addClass('rotatetranslate180');
	});
	$('.digital-button .photo3').mouseleave(function(){
		$('.digital-button .photo3').attr('src','assets/images/creative-design/digital3.svg');
		$('.digital-button .shadow').show();
		$('.digital-button .photo1').removeClass('rotate180');
		$('.digital-button .photo2').removeClass('rotatetranslate180');
	});

	$('.animation-button .photo3').mouseover(function(){
		$('.animation-button .photo3').attr('src','assets/images/creative-design/animation3pressed.svg');
		$('.animation-button .shadow').hide();
		$('.animation-button .photo1').addClass('rotate180');
		$('.animation-button .photo2').addClass('rotatetranslate180');
	});
	$('.animation-button .photo3').mouseleave(function(){
		$('.animation-button .photo3').attr('src','assets/images/creative-design/animation3.svg');
		$('.animation-button .shadow').show();
		$('.animation-button .photo1').removeClass('rotate180');
		$('.animation-button .photo2').removeClass('rotatetranslate180');
	});

	$('.creative-button .photo3').mouseover(function(){
		$('.creative-button .photo3').attr('src','assets/images/creative-design/creative3pressed.svg');
		$('.creative-button .shadow').hide();
		$('.creative-button .photo1').addClass('rotate180');
		$('.creative-button .photo2').addClass('rotatetranslate180');
	});
	$('.creative-button .photo3').mouseleave(function(){
		$('.creative-button .photo3').attr('src','assets/images/creative-design/creative3.svg');
		$('.creative-button .shadow').show();
		$('.creative-button .photo1').removeClass('rotate180');
		$('.creative-button .photo2').removeClass('rotatetranslate180');
	});
})

$(document).ready(function(){
	$('.photography-button .photo3').click(function(){
		$('html,body').animate({
    	scrollTop: $(".photography-section").offset().top},
    	500);
	});
	$('.digital-button .photo3').click(function(){
		$('html,body').animate({
    	scrollTop: $(".digital-section").offset().top},
    	1000);
	});
	$('.animation-button .photo3').click(function(){
		$('html,body').animate({
    	scrollTop: $(".animation-section").offset().top},
    	1000);
	});
	$('.creative-button .photo3').click(function(){
		$('html,body').animate({
    	scrollTop: $(".creative-section").offset().top},
    	1000);
	});
})


$(document).ready(function(){
 first_screen_width();
 $(window).on('resize', function(){
 	first_screen_width();
 });
 function first_screen_width(){
 	$('.first-screen').height($(window).height());
 	$('.second-screen').height($(window).height());
 	$('.third-screen').height($(window).height());
 	$('.fourth-screen').height($(window).height());
 	$('.fifth-screen').height($(window).height());
 }
})

$(document).ready(function(){
	var sound = $('.sound')[0];
        sound.volume = 0.2;
	$('.main-button').mouseover(function(){
		sound.play();
	});
})

window.onscroll = function() { scrollFunction() };
function scrollFunction() {
    var headerheight = $('header').height();
    if (document.body.scrollTop > headerheight|| document.documentElement.scrollTop > headerheight){
        document.querySelector('header').classList.add('header_fixed');
        document.getElementById("tp-button").style.display = "block";
    }
    else if (document.body.scrollTop <= headerheight|| document.documentElement.scrollTop <= headerheight){
        document.querySelector('header').classList.remove('header_fixed');
        document.getElementById("tp-button").style.display = "none";
    }
    
}

$(document).ready(function(){
	$('.androidbutton').mouseover(function(){
		$('.clock1').addClass('clock1rotation');
		$('.arrow1').addClass('clock1rotation');
		$('.androidbutton').attr('src','assets/images/technology/androidicon.svg')
	});
	$('.androidbutton').mouseleave(function(){
		$('.clock1').removeClass('clock1rotation');
		$('.arrow1').removeClass('clock1rotation');
		$('.androidbutton').attr('src','assets/images/technology/androidunpressed.svg');
	});

	$('.websitebutton').mouseover(function(){
		$('.clock2').addClass('clock2rotation');
		$('.arrow2').addClass('clock2rotation');
		$('.websitebutton').attr('src','assets/images/technology/websiteicon.svg');
	});
	$('.websitebutton').mouseleave(function(){
		$('.clock2').removeClass('clock2rotation');
		$('.arrow2').removeClass('clock2rotation');
		$('.websitebutton').attr('src','assets/images/technology/websiteunpressed.svg');
	});

	$('.softwarebutton').mouseover(function(){
		$('.clock3').addClass('clock3rotation');
		$('.arrow3').addClass('clock3rotation');
		$('.softwarebutton').attr('src','assets/images/technology/softwareicon.svg');
	});
	$('.softwarebutton').mouseleave(function(){
		$('.clock3').removeClass('clock3rotation');
		$('.arrow3').removeClass('clock3rotation');
		$('.softwarebutton').attr('src','assets/images/technology/softwareunpressed.svg');
	});

	$('.supportbutton').mouseover(function(){
		$('.clock4').addClass('clock4rotation');
		$('.arrow4').addClass('clock4rotation');
		$('.supportbutton').attr('src','assets/images/technology/supporticon.svg');
	});
	$('.supportbutton').mouseleave(function(){
		$('.clock4').removeClass('clock4rotation');
		$('.arrow4').removeClass('clock4rotation');
		$('.supportbutton').attr('src','assets/images/technology/supportunpressed.svg');
	});
	
        if ($(window).width() <= 767) {
            $('.androidbutton').mouseover(function(){
        		$('.clock1').addClass('clock1rotation');
        		$('.androidbutton').attr('src','assets/images/technology/android-xs-g.png')
        	});
        	$('.androidbutton').mouseleave(function(){
        		$('.clock1').removeClass('clock1rotation');
        		$('.androidbutton').attr('src','assets/images/technology/android-xs-w.png');
        	});
        
        	$('.websitebutton').mouseover(function(){
        		$('.clock2').addClass('clock2rotation');
        		$('.websitebutton').attr('src','assets/images/technology/website-xs-g.png');
        	});
        	$('.websitebutton').mouseleave(function(){
        		$('.clock2').removeClass('clock2rotation');
        		$('.websitebutton').attr('src','assets/images/technology/website-xs-w.png');
        	});
        
        	$('.softwarebutton').mouseover(function(){
        		$('.clock3').addClass('clock3rotation');
        		$('.softwarebutton').attr('src','assets/images/technology/software-xs-g.png');
        	});
        	$('.softwarebutton').mouseleave(function(){
        		$('.clock3').removeClass('clock3rotation');
        		$('.softwarebutton').attr('src','assets/images/technology/software-xs-w.png');
        	});
        
        	$('.supportbutton').mouseover(function(){
        		$('.clock4').addClass('clock4rotation');
        		$('.supportbutton').attr('src','assets/images/technology/support-xs-g.png');
        	});
        	$('.supportbutton').mouseleave(function(){
        		$('.clock4').removeClass('clock4rotation');
        		$('.supportbutton').attr('src','assets/images/technology/support-xs-w.png');
        	});
        }

	$('.click').mouseover(function(){
		$('.click').attr('src','images/Fill-Scrolling.gif');
	});
	$('.click').mouseleave(function(){
		$('.click').attr('src','images/Outer-Scrolling.gif');
	});

	$('.click').click(function(){
		$('html,body').animate({
        scrollTop: $("#second-screen").offset().top},
        1000);
    });

    $('.androidbutton').click(function(){
		$('html,body').animate({
        scrollTop: $("#second-screen").offset().top},
        1000);
    });

    $('.websitebutton').click(function(){
		$('html,body').animate({
        scrollTop: $("#third-screen").offset().top},
        1000);
    });

    $('.softwarebutton').click(function(){
		$('html,body').animate({
        scrollTop: $("#fourth-screen").offset().top},
        1000);
    });

    $('.supportbutton').click(function(){
		$('html,body').animate({
        scrollTop: $("#fifth-screen").offset().top},
        1000);
    });
    $('.top').click(function(){
		$('html,body').animate({
        scrollTop: $("body").offset().top},
        1000);
    });
})

/*===============Mouse Scroll Setup=============*/

$.scrollify({
    section : ".mousescroll",
    sectionName : "mouse-scroll",
    interstitialSection : "body",
    easing: "easeOutExpo",
    scrollSpeed: 500,
    offset : 0,
    scrollbars: true,
    standardScrollElements: "",
    setHeights: true,
    overflowScroll: true,
    updateHash: false,
    touchScroll:true,
    before:function() {},
    after:function() {},
    afterResize:function() {},
    afterRender:function() {}
  });

/*===============Magic Line JS=================*/
